class CreatePaths < ActiveRecord::Migration
  def change
    create_table :paths do |t|
      t.datetime :dateTime
      t.boolean :visible
      t.references :user, index: true, foreign_key: true
      t.references :route, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
