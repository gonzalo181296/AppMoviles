class PagesController < ApplicationController
  def index
  end

  def about_us
  end

  def tos
  end

  def faq
  end

  def contact_us
  end
end
