class CreateRoutes < ActiveRecord::Migration
  def change
    create_table :routes do |t|
      t.decimal :longitude1
      t.decimal :longitude2
      t.decimal :latitud1
      t.decimal :latitud2

      t.timestamps null: false
    end
  end
end
