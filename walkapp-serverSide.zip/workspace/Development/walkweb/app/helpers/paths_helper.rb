module PathsHelper
end
